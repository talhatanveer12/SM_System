<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AssignCourseController extends Controller
{
    //
}
