<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FeeParticulars;
use Illuminate\Support\Facades\DB;

class FeeParticularsController extends Controller
{

}
